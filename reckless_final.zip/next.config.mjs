/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  /* Removed PWA plugin to fix build crash */
};

export default nextConfig;
